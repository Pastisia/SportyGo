<?php
include '../config/db.php';

$sql = "SELECT * FROM lapangan ORDER BY id DESC";
$result = $conn->query($sql);

$response = array();

if ($result->num_rows > 0) {
    $response['success'] = true;
    $response['data'] = array();

    while ($row = $result->fetch_assoc()) {
        $response['data'][] = array(
            "id" => $row["id"],
            "nama_lapangan" => $row["nama_lapangan"],
            "harga_per_jam" => $row["harga_per_jam"],
            "deskripsi" => $row["deskripsi"],
            "lokasi" => $row["lokasi"],
            "foto_url" => $row["foto_url"]
        );
    }
} else {
    $response['success'] = false;
    $response['message'] = "Tidak ada data lapangan.";
}

echo json_encode($response);
?>
