<?php
include '../config/db.php';

$id_user = $_GET['id_user'];

$sql = "SELECT booking.*, lapangan.nama_lapangan, lapangan.lokasi
        FROM booking
        JOIN lapangan ON booking.id_lapangan = lapangan.id
        WHERE booking.id_user = ?
        ORDER BY booking.tanggal_booking DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_user);
$stmt->execute();
$result = $stmt->get_result();

$response = array();

if ($result->num_rows > 0) {
    $response['success'] = true;
    $response['data'] = array();
    while ($row = $result->fetch_assoc()) {
        $response['data'][] = $row;
    }
} else {
    $response['success'] = false;
    $response['message'] = "Belum ada booking.";
}

echo json_encode($response);
?>
