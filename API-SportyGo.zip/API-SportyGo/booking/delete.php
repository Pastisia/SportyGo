<?php
include '../config/db.php';

// Validasi apakah parameter 'id' dikirim
if (!isset($_POST['id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'ID tidak dikirim.'
    ]);
    exit;
}

$id = intval($_POST['id']); // pastikan integer

if ($id <= 0) {
    echo json_encode([
        'success' => false,
        'message' => 'ID tidak valid.'
    ]);
    exit;
}

$sql = "DELETE FROM booking WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

$response = [];

if ($stmt->execute()) {
    $response['success'] = true;
    $response['message'] = "Booking berhasil dihapus.";
} else {
    $response['success'] = false;
    $response['message'] = "Gagal menghapus booking.";
}

echo json_encode($response);
?>
