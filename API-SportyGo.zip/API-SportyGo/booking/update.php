<?php
include '../config/db.php';

file_put_contents("log.txt", json_encode($_POST)); // untuk debug


$id = $_POST['id'];
$tanggal = $_POST['tanggal_booking'];
$jam_mulai = $_POST['jam_mulai'];
$jam_selesai = $_POST['jam_selesai'];

$sql = "UPDATE booking SET tanggal_booking=?, jam_mulai=?, jam_selesai=? WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssi", $tanggal, $jam_mulai, $jam_selesai, $id);

$response = array();

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        $response['success'] = true;
        $response['message'] = "Booking berhasil diubah.";
    } else {
        $response['success'] = false;
        $response['message'] = "Tidak ada data yang diubah (mungkin nilainya sama).";
    }
} else {
    $response['success'] = false;
    $response['message'] = "Gagal mengubah booking.";
}


echo json_encode($response);
?>
