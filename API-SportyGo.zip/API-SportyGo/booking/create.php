<?php
include '../config/db.php';

$id_user = $_POST['id_user'] ?? null;
$id_lapangan = $_POST['id_lapangan'] ?? null;
$tanggal_booking = $_POST['tanggal_booking'] ?? null;
$jam_mulai = $_POST['jam_mulai'] ?? null;
$jam_selesai = $_POST['jam_selesai'] ?? null;

// Debug log (sementara) — bisa dihapus nanti
file_put_contents("debug_booking.txt", json_encode([
  "id_user" => $id_user,
  "id_lapangan" => $id_lapangan,
  "tanggal_booking" => $tanggal_booking,
  "jam_mulai" => $jam_mulai,
  "jam_selesai" => $jam_selesai,
]), FILE_APPEND);

$response = [];

if (!$id_user || !$id_lapangan || !$tanggal_booking || !$jam_mulai || !$jam_selesai) {
    $response['success'] = false;
    $response['message'] = 'Data tidak lengkap';
    echo json_encode($response);
    exit;
}

$sql = "INSERT INTO booking (id_user, id_lapangan, tanggal_booking, jam_mulai, jam_selesai) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iisss", $id_user, $id_lapangan, $tanggal_booking, $jam_mulai, $jam_selesai);

if ($stmt->execute()) {
    $response['success'] = true;
    $response['message'] = 'Booking berhasil';
} else {
    $response['success'] = false;
    $response['message'] = 'Gagal booking: ' . $stmt->error;
}

header('Content-Type: application/json');
echo json_encode($response);
?>
