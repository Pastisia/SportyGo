<?php
$host = "localhost";
$user = "fore6986_Gema";
$pass = "gema280105";
$db = "fore6986_db_SportyGo";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
