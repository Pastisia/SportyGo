<?php
include '../config/db.php';

$id = $_GET['id'];

$sql = "SELECT id, name, email FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

$response = array();

if ($result->num_rows > 0) {
    $response['success'] = true;
    $response['data'] = $result->fetch_assoc();
} else {
    $response['success'] = false;
    $response['message'] = "User tidak ditemukan";
}

echo json_encode($response);
?>
