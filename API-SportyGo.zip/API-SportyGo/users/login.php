<?php
include '../config/db.php';

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

$response = array();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password'])) {
        $response['success'] = true;
        $response['message'] = "Login berhasil";
        $response['data'] = array(
            "id" => $row['id'],
            "name" => $row['name'],
            "email" => $row['email']
        );
    } else {
        $response['success'] = false;
        $response['message'] = "Password salah";
    }
} else {
    $response['success'] = false;
    $response['message'] = "Email tidak ditemukan";
}

header('Content-Type: application/json');
echo json_encode($response);
?>
