<?php
include '../config/db.php';

$name = $_POST['name'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

$response = array();

// Cek apakah email sudah ada
$check = $conn->prepare("SELECT id FROM users WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
$check->store_result();

if (empty($_POST['name']) || empty($_POST['email']) || empty($_POST['password'])) {
    $response['success'] = false;
    $response['message'] = "Semua field harus diisi";
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

if ($check->num_rows > 0) {
    $response['success'] = false;
    $response['message'] = "Email sudah terdaftar";
} else {
    // Lanjutkan insert jika email belum terdaftar
    $sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $name, $email, $password);

    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = "Registrasi berhasil";
    } else {
        $response['success'] = false;
        $response['message'] = "Registrasi gagal: " . mysqli_error($conn);
    }

    $stmt->close();
}

$check->close();
$conn->close();

header('Content-Type: application/json');
echo json_encode($response);
?>
